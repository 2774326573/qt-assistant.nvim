-- Qt Assistant Plugin - 初始化模块
-- Plugin initialization module

return require('qt-assistant')